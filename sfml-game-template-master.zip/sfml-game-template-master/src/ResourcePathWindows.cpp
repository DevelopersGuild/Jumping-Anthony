#include "ResourcePath.h"

std::string resourcePath()
{
	return "..\\..\\";
}
